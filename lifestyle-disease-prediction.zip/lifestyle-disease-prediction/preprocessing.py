"""
Data preprocessing and feature engineering for lifestyle disease prediction.
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split


def load_data(filepath: str) -> pd.DataFrame:
    df = pd.read_csv(filepath)
    return df


def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    num_cols = df.select_dtypes(include=np.number).columns
    for col in num_cols:
        if df[col].isnull().sum() > 0:
            df[col].fillna(df[col].median(), inplace=True)
    return df


def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # BMI category
    df["bmi_category"] = pd.cut(
        df["bmi"],
        bins=[0, 18.5, 25, 30, 100],
        labels=[0, 1, 2, 3]
    ).astype(int)

    # Hypertension flag
    df["hypertension"] = (
        (df["blood_pressure_systolic"] >= 140) |
        (df["blood_pressure_diastolic"] >= 90)
    ).astype(int)

    # Diabetic risk flag
    df["diabetic_risk"] = (df["blood_glucose"] >= 126).astype(int)

    # High cholesterol flag
    df["high_cholesterol"] = (df["cholesterol"] >= 240).astype(int)

    # Age group
    df["age_group"] = pd.cut(
        df["age"],
        bins=[0, 30, 45, 60, 100],
        labels=[0, 1, 2, 3]
    ).astype(int)

    # Lifestyle score (higher = healthier)
    df["lifestyle_score"] = (
        df["physical_activity_hrs"] / 2 +
        df["sleep_hours"] / 2 +
        df["diet_quality"] -
        df["stress_level"] / 2 -
        df["smoking"] * 3 -
        df["alcohol_units_week"] / 5
    )

    return df


def split_and_scale(df: pd.DataFrame, target: str = "disease", test_size: float = 0.2):
    X = df.drop(columns=[target])
    y = df[target]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, X.columns.tolist()


def preprocess_pipeline(filepath: str):
    df = load_data(filepath)
    df = handle_missing(df)
    df = feature_engineering(df)
    return split_and_scale(df)
