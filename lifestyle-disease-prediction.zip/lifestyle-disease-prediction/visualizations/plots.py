"""
Visualizations for lifestyle disease prediction project.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
from sklearn.metrics import roc_curve, auc, ConfusionMatrixDisplay
import os

OUTPUT_DIR = os.path.dirname(__file__)
PALETTE = {
    "healthy": "#2DD4BF",
    "disease": "#F43F5E",
    "accent": "#6366F1",
    "bg": "#0F172A",
    "card": "#1E293B",
    "text": "#F1F5F9",
    "muted": "#94A3B8",
}

def _style():
    plt.rcParams.update({
        "figure.facecolor": PALETTE["bg"],
        "axes.facecolor": PALETTE["card"],
        "axes.edgecolor": PALETTE["muted"],
        "axes.labelcolor": PALETTE["text"],
        "xtick.color": PALETTE["muted"],
        "ytick.color": PALETTE["muted"],
        "text.color": PALETTE["text"],
        "grid.color": "#334155",
        "grid.linestyle": "--",
        "grid.alpha": 0.5,
        "font.family": "DejaVu Sans",
    })


# ── 1. Class Distribution ────────────────────────────────────────────────────
def plot_class_distribution(df: pd.DataFrame):
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.patch.set_facecolor(PALETTE["bg"])

    counts = df["disease"].value_counts().sort_index()
    labels = ["Healthy", "Disease"]
    colors = [PALETTE["healthy"], PALETTE["disease"]]

    # Bar
    axes[0].bar(labels, counts.values, color=colors, width=0.5, edgecolor="none")
    for i, v in enumerate(counts.values):
        axes[0].text(i, v + 10, str(v), ha="center", color=PALETTE["text"], fontsize=11, fontweight="bold")
    axes[0].set_title("Class Distribution", color=PALETTE["text"], fontsize=14, pad=12)
    axes[0].set_ylabel("Count", color=PALETTE["muted"])
    axes[0].set_facecolor(PALETTE["card"])

    # Pie
    wedges, texts, autotexts = axes[1].pie(
        counts.values, labels=labels, colors=colors,
        autopct="%1.1f%%", startangle=90,
        wedgeprops={"edgecolor": PALETTE["bg"], "linewidth": 2}
    )
    for t in texts + autotexts:
        t.set_color(PALETTE["text"])
    axes[1].set_title("Proportion", color=PALETTE["text"], fontsize=14, pad=12)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "class_distribution.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ── 2. Feature Correlation Heatmap ──────────────────────────────────────────
def plot_correlation_heatmap(df: pd.DataFrame):
    _style()
    corr = df.corr()
    fig, ax = plt.subplots(figsize=(14, 11))
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["bg"])

    cmap = LinearSegmentedColormap.from_list(
        "custom", [PALETTE["disease"], PALETTE["bg"], PALETTE["healthy"]]
    )
    im = ax.imshow(corr.values, cmap=cmap, vmin=-1, vmax=1)
    cbar = plt.colorbar(im, ax=ax, fraction=0.03)
    cbar.ax.yaxis.set_tick_params(color=PALETTE["muted"])
    plt.setp(cbar.ax.yaxis.get_ticklabels(), color=PALETTE["text"])

    ax.set_xticks(range(len(corr.columns)))
    ax.set_yticks(range(len(corr.columns)))
    ax.set_xticklabels(corr.columns, rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(corr.columns, fontsize=9)

    for i in range(len(corr)):
        for j in range(len(corr.columns)):
            ax.text(j, i, f"{corr.values[i, j]:.2f}", ha="center", va="center",
                    fontsize=7, color="white" if abs(corr.values[i, j]) > 0.4 else PALETTE["muted"])

    ax.set_title("Feature Correlation Matrix", color=PALETTE["text"], fontsize=15, pad=15)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "correlation_heatmap.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ── 3. Key Feature Distributions ────────────────────────────────────────────
def plot_feature_distributions(df: pd.DataFrame):
    _style()
    features = ["age", "bmi", "blood_glucose", "cholesterol", "stress_level", "physical_activity_hrs"]
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.patch.set_facecolor(PALETTE["bg"])
    fig.suptitle("Feature Distributions by Disease Status", color=PALETTE["text"], fontsize=15, y=1.01)

    for ax, feat in zip(axes.flat, features):
        for label, color in [(0, PALETTE["healthy"]), (1, PALETTE["disease"])]:
            vals = df[df["disease"] == label][feat]
            ax.hist(vals, bins=25, alpha=0.6, color=color,
                    label=("Healthy" if label == 0 else "Disease"), edgecolor="none")
        ax.set_title(feat.replace("_", " ").title(), color=PALETTE["text"], fontsize=11)
        ax.set_facecolor(PALETTE["card"])
        ax.legend(fontsize=8)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "feature_distributions.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ── 4. Confusion Matrix ──────────────────────────────────────────────────────
def plot_confusion_matrix(cm, labels=("Healthy", "Disease")):
    _style()
    fig, ax = plt.subplots(figsize=(7, 6))
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])

    cmap = LinearSegmentedColormap.from_list("cm", [PALETTE["card"], PALETTE["accent"]])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(ax=ax, cmap=cmap, colorbar=False)

    for text in disp.text_.ravel():
        text.set_color(PALETTE["text"])
        text.set_fontsize(14)
        text.set_fontweight("bold")

    ax.set_title("Confusion Matrix — SVM", color=PALETTE["text"], fontsize=14, pad=12)
    ax.xaxis.label.set_color(PALETTE["muted"])
    ax.yaxis.label.set_color(PALETTE["muted"])
    ax.tick_params(colors=PALETTE["muted"])

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "confusion_matrix.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ── 5. ROC Curve ─────────────────────────────────────────────────────────────
def plot_roc_curve(y_test, y_prob):
    _style()
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    roc_auc = auc(fpr, tpr)

    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])

    ax.plot(fpr, tpr, color=PALETTE["accent"], lw=2.5,
            label=f"SVM (AUC = {roc_auc:.3f})")
    ax.plot([0, 1], [0, 1], color=PALETTE["muted"], lw=1.5, linestyle="--", label="Random")
    ax.fill_between(fpr, tpr, alpha=0.08, color=PALETTE["accent"])

    ax.set_xlabel("False Positive Rate", color=PALETTE["muted"])
    ax.set_ylabel("True Positive Rate", color=PALETTE["muted"])
    ax.set_title("ROC Curve — SVM Classifier", color=PALETTE["text"], fontsize=14, pad=12)
    ax.legend(loc="lower right", framealpha=0.2)
    ax.grid(True)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "roc_curve.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ── 6. Risk Factor Bar Chart ─────────────────────────────────────────────────
def plot_risk_factors(df: pd.DataFrame):
    _style()
    risk_features = [
        "smoking", "family_history", "hypertension", "diabetic_risk",
        "high_cholesterol", "bmi_category"
    ]
    # Only use engineered features if present
    available = [f for f in risk_features if f in df.columns]

    rates = []
    for feat in available:
        rate = df[df[feat] >= 1]["disease"].mean() * 100
        rates.append(rate)

    fig, ax = plt.subplots(figsize=(10, 6))
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])

    colors = [PALETTE["disease"] if r > 60 else PALETTE["accent"] for r in rates]
    bars = ax.barh(available, rates, color=colors, edgecolor="none", height=0.55)
    for bar, rate in zip(bars, rates):
        ax.text(rate + 0.5, bar.get_y() + bar.get_height() / 2,
                f"{rate:.1f}%", va="center", color=PALETTE["text"], fontsize=10)

    ax.set_xlabel("Disease Rate (%)", color=PALETTE["muted"])
    ax.set_title("Disease Rate by Risk Factor", color=PALETTE["text"], fontsize=14, pad=12)
    ax.set_xlim(0, 110)
    ax.grid(axis="x", alpha=0.3)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "risk_factors.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")
