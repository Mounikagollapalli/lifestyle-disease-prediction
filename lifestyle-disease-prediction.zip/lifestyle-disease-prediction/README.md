# Lifestyle Disease Prediction 🩺

A machine learning application that predicts lifestyle disease risk from patient health parameters using a **Support Vector Machine (SVM)** classifier.

---

## Project Structure

```
lifestyle-disease-prediction/
├── data/
│   ├── generate_dataset.py      # Synthetic dataset generator
│   └── health_data.csv          # Generated dataset (1500 records)
├── models/
│   └── svm_model.pkl            # Saved trained model + scaler
├── visualizations/
│   ├── plots.py                 # All visualization functions
│   ├── class_distribution.png
│   ├── correlation_heatmap.png
│   ├── feature_distributions.png
│   ├── risk_factors.png
│   ├── confusion_matrix.png
│   └── roc_curve.png
├── preprocessing.py             # Data loading, cleaning, feature engineering
├── model.py                     # SVM training, evaluation, persistence
├── train.py                     # End-to-end training pipeline
├── predict.py                   # CLI for single-patient prediction
└── requirements.txt
```

---

## Features Used

| Feature | Description |
|---|---|
| `age` | Patient age in years |
| `bmi` | Body Mass Index |
| `blood_pressure_systolic` | Systolic blood pressure (mmHg) |
| `blood_pressure_diastolic` | Diastolic blood pressure (mmHg) |
| `cholesterol` | Total cholesterol (mg/dL) |
| `blood_glucose` | Fasting blood glucose (mg/dL) |
| `physical_activity_hrs` | Weekly physical activity (hours) |
| `sleep_hours` | Nightly sleep duration (hours) |
| `smoking` | Smoking status (0/1) |
| `alcohol_units_week` | Weekly alcohol consumption (units) |
| `stress_level` | Stress level (1–10) |
| `family_history` | Family disease history (0/1) |
| `diet_quality` | Diet quality score (1–10) |

### Engineered Features
- **bmi_category** — Underweight / Normal / Overweight / Obese (0–3)
- **hypertension** — BP ≥ 140/90 flag
- **diabetic_risk** — Fasting glucose ≥ 126 mg/dL flag
- **high_cholesterol** — Cholesterol ≥ 240 mg/dL flag
- **age_group** — Decade-based age band
- **lifestyle_score** — Composite score from activity, sleep, diet, smoking, stress

---

## Setup

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/lifestyle-disease-prediction.git
cd lifestyle-disease-prediction

# Install dependencies
pip install -r requirements.txt

# Generate dataset
python data/generate_dataset.py
```

---

## Usage

### Train the model
```bash
python train.py
```
This runs the full pipeline:
1. Data loading & preprocessing
2. Feature engineering
3. Exploratory visualizations
4. SVM training with GridSearchCV (5-fold CV)
5. Evaluation (Accuracy, F1, ROC-AUC)
6. Model + scaler saved to `models/svm_model.pkl`

### Predict for a single patient
```bash
python predict.py
```
Follow the prompts to enter health parameters and get a risk assessment.

---

## Model Details

| Parameter | Value |
|---|---|
| Algorithm | Support Vector Machine (SVM) |
| Kernel | RBF (Radial Basis Function) |
| Hyperparameter Tuning | GridSearchCV (5-fold CV) |
| Scaling | StandardScaler |
| Search space | C ∈ {0.1, 1, 10}, kernel ∈ {rbf, linear} |

---

## Results

| Metric | Score |
|---|---|
| Accuracy | ~85–88% |
| F1 Score | ~0.88–0.92 |
| ROC-AUC | ~0.88–0.93 |

---

## Visualizations

| Plot | Description |
|---|---|
| `class_distribution.png` | Bar + pie of healthy vs disease |
| `correlation_heatmap.png` | Feature correlation matrix |
| `feature_distributions.png` | Histograms by disease status |
| `risk_factors.png` | Disease rate per binary risk factor |
| `confusion_matrix.png` | Predicted vs actual labels |
| `roc_curve.png` | ROC curve with AUC |

---

## Tech Stack

- **Python 3.9+**
- **Pandas** — data manipulation
- **NumPy** — numerical operations
- **Scikit-learn** — SVM, preprocessing, evaluation
- **Matplotlib** — all visualizations

---

## Disclaimer

This project is for educational and demonstration purposes only. It is not a substitute for professional medical diagnosis or advice.
