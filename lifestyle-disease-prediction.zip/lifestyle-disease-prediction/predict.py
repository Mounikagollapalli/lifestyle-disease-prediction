"""
CLI for single-patient disease risk prediction.
Usage: python predict.py
"""
import pickle
import numpy as np
import pandas as pd
from preprocessing import feature_engineering


def load_bundle(path: str = "models/svm_model.pkl"):
    with open(path, "rb") as f:
        return pickle.load(f)


def get_patient_input() -> dict:
    print("\n─── Enter Patient Health Parameters ───")
    def inp(prompt, cast=float):
        while True:
            try:
                return cast(input(f"  {prompt}: "))
            except ValueError:
                print("  Invalid input. Please try again.")

    return {
        "age": inp("Age (years)", int),
        "bmi": inp("BMI"),
        "blood_pressure_systolic": inp("Systolic BP (mmHg)", int),
        "blood_pressure_diastolic": inp("Diastolic BP (mmHg)", int),
        "cholesterol": inp("Cholesterol (mg/dL)", int),
        "blood_glucose": inp("Blood Glucose (mg/dL)", int),
        "physical_activity_hrs": inp("Physical Activity (hrs/week)"),
        "sleep_hours": inp("Sleep (hrs/night)"),
        "smoking": inp("Smoking (0=No, 1=Yes)", int),
        "alcohol_units_week": inp("Alcohol (units/week)", int),
        "stress_level": inp("Stress Level (1-10)", int),
        "family_history": inp("Family History of Disease (0=No, 1=Yes)", int),
        "diet_quality": inp("Diet Quality Score (1-10)", int),
    }


def predict(patient: dict, bundle: dict) -> None:
    model = bundle["model"]
    scaler = bundle["scaler"]

    # Apply same feature engineering
    df = pd.DataFrame([patient])
    df = feature_engineering(df)

    # Get feature names from scaler (same order as training)
    X_scaled = scaler.transform(df)
    prob = model.predict_proba(X_scaled)[0][1]
    pred = model.predict(X_scaled)[0]

    print("\n════════════════════════════════════")
    print("         PREDICTION RESULT")
    print("════════════════════════════════════")
    if pred == 1:
        print(f"  ⚠  HIGH RISK of Lifestyle Disease")
    else:
        print(f"  ✓  LOW RISK of Lifestyle Disease")
    print(f"  Risk Probability : {prob*100:.1f}%")
    if prob < 0.3:
        print("  Category         : Low Risk")
    elif prob < 0.6:
        print("  Category         : Moderate Risk")
    else:
        print("  Category         : High Risk")
    print("════════════════════════════════════")
    print("  Note: This is a screening tool only.")
    print("  Consult a healthcare professional.")
    print("════════════════════════════════════\n")


if __name__ == "__main__":
    try:
        bundle = load_bundle()
    except FileNotFoundError:
        print("Model not found. Run `python train.py` first.")
        exit(1)

    patient = get_patient_input()
    predict(patient, bundle)
