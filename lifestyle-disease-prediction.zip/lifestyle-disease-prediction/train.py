"""
Main training pipeline for Lifestyle Disease Prediction using SVM.
Run: python train.py
"""
import os
import sys
import pandas as pd
import numpy as np

from preprocessing import load_data, handle_missing, feature_engineering, split_and_scale
from model import train_svm, evaluate_model, cross_validate, save_model
from visualizations.plots import (
    plot_class_distribution,
    plot_correlation_heatmap,
    plot_feature_distributions,
    plot_confusion_matrix,
    plot_roc_curve,
    plot_risk_factors,
)

DATA_PATH = "data/health_data.csv"
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)


def main():
    print("=" * 60)
    print("  Lifestyle Disease Prediction — SVM Pipeline")
    print("=" * 60)

    # ── 1. Load & Preprocess ─────────────────────────────────────
    print("\n[1/5] Loading and preprocessing data...")
    df_raw = load_data(DATA_PATH)
    df = handle_missing(df_raw.copy())
    df = feature_engineering(df)

    print(f"  Dataset shape : {df.shape}")
    print(f"  Disease rate  : {df['disease'].mean()*100:.1f}%")

    # ── 2. Visualize Data ────────────────────────────────────────
    print("\n[2/5] Generating exploratory visualizations...")
    plot_class_distribution(df)
    plot_correlation_heatmap(df)
    plot_feature_distributions(df)
    plot_risk_factors(df)

    # ── 3. Split & Scale ─────────────────────────────────────────
    print("\n[3/5] Splitting and scaling features...")
    X_train, X_test, y_train, y_test, scaler, feature_names = split_and_scale(df)
    print(f"  Train samples : {X_train.shape[0]}")
    print(f"  Test  samples : {X_test.shape[0]}")
    print(f"  Features      : {len(feature_names)}")

    # ── 4. Train SVM ─────────────────────────────────────────────
    print("\n[4/5] Training SVM classifier (with GridSearchCV)...")
    model = train_svm(X_train, y_train, tune=True)
    cv_scores = cross_validate(model, X_train, y_train)

    # ── 5. Evaluate ───────────────────────────────────────────────
    print("\n[5/5] Evaluating model...")
    metrics = evaluate_model(model, X_test, y_test)

    print(f"\n{'─'*40}")
    print(f"  Accuracy  : {metrics['accuracy']*100:.2f}%")
    print(f"  F1 Score  : {metrics['f1_score']:.4f}")
    print(f"  ROC-AUC   : {metrics['roc_auc']:.4f}")
    print(f"{'─'*40}")
    print(f"\nClassification Report:\n{metrics['classification_report']}")

    plot_confusion_matrix(metrics["confusion_matrix"])
    plot_roc_curve(y_test, metrics["y_prob"])

    # Save model
    save_model(model, scaler, filepath=f"{MODEL_DIR}/svm_model.pkl")

    print("\n✓ Pipeline complete. Check visualizations/ for plots.")
    return metrics


if __name__ == "__main__":
    main()
