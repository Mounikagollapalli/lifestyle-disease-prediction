"""
Generate synthetic health dataset for lifestyle disease prediction.
"""
import numpy as np
import pandas as pd

np.random.seed(42)
N = 1500

age = np.random.randint(20, 75, N)
bmi = np.round(np.random.normal(27, 5, N).clip(15, 50), 1)
blood_pressure_systolic = np.random.randint(90, 180, N)
blood_pressure_diastolic = np.random.randint(60, 120, N)
cholesterol = np.random.randint(130, 320, N)
blood_glucose = np.random.randint(70, 300, N)
physical_activity_hrs = np.round(np.random.exponential(3, N).clip(0, 14), 1)
sleep_hours = np.round(np.random.normal(6.8, 1.2, N).clip(3, 12), 1)
smoking = np.random.choice([0, 1], N, p=[0.65, 0.35])
alcohol_units_week = np.random.randint(0, 25, N)
stress_level = np.random.randint(1, 11, N)
family_history = np.random.choice([0, 1], N, p=[0.6, 0.4])
diet_quality = np.random.randint(1, 11, N)

# Disease label logic (multi-factor)
risk_score = (
    (age > 45).astype(int) * 2 +
    (bmi > 30).astype(int) * 2 +
    (blood_pressure_systolic > 140).astype(int) * 2 +
    (cholesterol > 240).astype(int) * 2 +
    (blood_glucose > 125).astype(int) * 3 +
    (physical_activity_hrs < 2).astype(int) * 1 +
    (sleep_hours < 6).astype(int) * 1 +
    smoking * 2 +
    (alcohol_units_week > 14).astype(int) * 1 +
    (stress_level > 7).astype(int) * 1 +
    family_history * 2 +
    (diet_quality < 4).astype(int) * 1
)

disease = (risk_score >= 7).astype(int)
# Add some noise
flip = np.random.choice([0, 1], N, p=[0.92, 0.08])
disease = np.where(flip, 1 - disease, disease)

df = pd.DataFrame({
    "age": age,
    "bmi": bmi,
    "blood_pressure_systolic": blood_pressure_systolic,
    "blood_pressure_diastolic": blood_pressure_diastolic,
    "cholesterol": cholesterol,
    "blood_glucose": blood_glucose,
    "physical_activity_hrs": physical_activity_hrs,
    "sleep_hours": sleep_hours,
    "smoking": smoking,
    "alcohol_units_week": alcohol_units_week,
    "stress_level": stress_level,
    "family_history": family_history,
    "diet_quality": diet_quality,
    "disease": disease
})

df.to_csv("health_data.csv", index=False)
print(f"Dataset created: {df.shape}")
print(df["disease"].value_counts())
