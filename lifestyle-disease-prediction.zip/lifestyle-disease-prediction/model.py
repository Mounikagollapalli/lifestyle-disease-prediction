"""
SVM model training, evaluation, and persistence for lifestyle disease prediction.
"""
import numpy as np
import pickle
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, accuracy_score, f1_score
)


def train_svm(X_train, y_train, tune: bool = True):
    """Train SVM with optional hyperparameter tuning."""
    if tune:
        param_grid = {
            "C": [0.1, 1, 10],
            "kernel": ["rbf", "linear"],
            "gamma": ["scale", "auto"],
        }
        svm = SVC(probability=True, random_state=42)
        grid = GridSearchCV(svm, param_grid, cv=5, scoring="f1", n_jobs=-1, verbose=0)
        grid.fit(X_train, y_train)
        print(f"Best params: {grid.best_params_}")
        return grid.best_estimator_
    else:
        svm = SVC(C=1, kernel="rbf", gamma="scale", probability=True, random_state=42)
        svm.fit(X_train, y_train)
        return svm


def evaluate_model(model, X_test, y_test):
    """Return a dict of evaluation metrics."""
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "f1_score": round(f1_score(y_test, y_pred), 4),
        "roc_auc": round(roc_auc_score(y_test, y_prob), 4),
        "confusion_matrix": confusion_matrix(y_test, y_pred),
        "classification_report": classification_report(y_test, y_pred),
        "y_pred": y_pred,
        "y_prob": y_prob,
    }
    return metrics


def cross_validate(model, X_train, y_train, cv: int = 5):
    scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="f1")
    print(f"Cross-val F1: {scores.mean():.4f} ± {scores.std():.4f}")
    return scores


def save_model(model, scaler, filepath: str = "models/svm_model.pkl"):
    with open(filepath, "wb") as f:
        pickle.dump({"model": model, "scaler": scaler}, f)
    print(f"Model saved to {filepath}")


def load_model(filepath: str = "models/svm_model.pkl"):
    with open(filepath, "rb") as f:
        bundle = pickle.load(f)
    return bundle["model"], bundle["scaler"]


def predict_single(model, scaler, feature_dict: dict, feature_names: list):
    """Predict disease risk for a single patient record."""
    import pandas as pd
    row = pd.DataFrame([feature_dict])[feature_names]
    row_scaled = scaler.transform(row)
    pred = model.predict(row_scaled)[0]
    prob = model.predict_proba(row_scaled)[0][1]
    return {"prediction": int(pred), "risk_probability": round(float(prob), 4)}
